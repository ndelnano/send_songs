var querystring = require('querystring');

var client_id = '12389b3e23114f0f9d278063ae5bbbd4'
var redirect_uri = 'https://qmzibslied.execute-api.us-east-1.amazonaws.com/prod'

exports.handler = (event, context, callback) => {

  var state = generateRandomString(16);
  var stateKey = 'spotify_auth_state';

  var scope = 'user-read-private user-read-email';
  var url = 'https://accounts.spotify.com/authorize?' +
    querystring.stringify({
      response_type: 'code',
      client_id: client_id,
      scope: scope,
      redirect_uri: redirect_uri,
      state: state
    })

  callback(null, url);

}

var generateRandomString = function(length) {
  var text = '';
  var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi
  pqrstuvwxyz0123456789';

  for (var i = 0; i < length; i++) {
    text += possible.charAt(Math.floor(Math.random() * possible.length));
  }
  return text;
};

